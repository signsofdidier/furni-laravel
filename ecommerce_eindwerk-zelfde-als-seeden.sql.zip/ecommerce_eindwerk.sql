-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 20 jun 2025 om 15:01
-- Serverversie: 8.3.0
-- PHP-versie: 8.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_eindwerk`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `addresses`
--

DROP TABLE IF EXISTS `addresses`;
CREATE TABLE IF NOT EXISTS `addresses` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street_address` text COLLATE utf8mb4_unicode_ci,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blockquote` text COLLATE utf8mb4_unicode_ci,
  `blockquote_author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `category_id` bigint UNSIGNED DEFAULT NULL,
  `brand_id` bigint UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blogs_slug_unique` (`slug`),
  KEY `blogs_user_id_foreign` (`user_id`),
  KEY `blogs_category_id_foreign` (`category_id`),
  KEY `blogs_brand_id_foreign` (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `slug`, `excerpt`, `content`, `image`, `blockquote`, `blockquote_author`, `user_id`, `category_id`, `brand_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Pure is the most furniture.', 'pure-is-the-most-furniture', 'These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice hand, organizations have the need for integrating in IT departments new technologies.', 'These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice hand, organizations have the need for integrating in IT departments new technologies.\n\nA wonderful serenity has taken possssion of my entire souing like these sweet mornng spring with my whole heart I am alone, and feel the charm of existenceths spot whch was create of souls like mineing am so happy my dear frend so absori bed in the exquste sens of mere.\n\nA wonderful serenity has taken posseson of my entire soung like these sweet mornngs spring enjoy with my whole heart I am alone and feel the charm of exstenceths spot whch was created ouls like mineing am so happy my dear frend so absoribed in the exquste sense of mere tranquil that neglect my talentsr I should bye ncapable of drawng and single stroke at the A wonderful se taken possesson of my entre souing like.', 'blogs/furniture-9.jpg', 'Words can be like X-rays, if you use them properly—they’ll go through anything. You read and you’re pierced.', 'Aldous Huxley', 6, NULL, NULL, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(2, 'Minimalism in your room.', 'minimalism-in-your-room', 'souls like mineing am so happy my dear frend so absori bed in the exquste sens of mere.', 'These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice hand, organizations have the need for integrating in IT departments new technologies.\n\nA wonderful serenity has taken possssion of my entire souing like these sweet mornng spring with my whole heart I am alone, and feel the charm of existenceths spot whch was create of souls like mineing am so happy my dear frend so absori bed in the exquste sens of mere.\n\nA wonderful serenity has taken posseson of my entire soung like these sweet mornngs spring enjoy with my whole heart I am alone and feel the charm of exstenceths spot whch was created ouls like mineing am so happy my dear frend so absoribed in the exquste sense of mere tranquil that neglect my talentsr I should bye ncapable of drawng and single stroke at the A wonderful se taken possesson of my entre souing like.', 'blogs/furniture-8.jpg', 'I should bye ncapable of drawng and single.', 'Carl Larsson', 1, NULL, NULL, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(3, 'Build up your kitchen.', 'build-up-your-kitchen', 'These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice hand, organizations', 'These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice hand, organizations have the need for integrating in IT departments new technologies.\n\nA wonderful serenity has taken possssion of my entire souing like these sweet mornng spring with my whole heart I am alone, and feel the charm of existenceths spot whch was create of souls like mineing am so happy my dear frend so absori bed in the exquste sens of mere.\n\nA wonderful serenity has taken posseson of my entire soung like these sweet mornngs spring enjoy with my whole heart I am alone and feel the charm of exstenceths spot whch was created ouls like mineing am so happy my dear frend so absoribed in the exquste sense of mere tranquil that neglect my talentsr I should bye ncapable of drawng and single stroke at the A wonderful se taken possesson of my entre souing like.', 'blogs/furniture-7.jpg', 'Talentsr I should bye', 'Souing', 2, NULL, NULL, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(4, 'Pure is the most furniture.', 'pure-is-like-the-most-furniture', 'A wonderful serenity has taken possssion of my entire souing like these sweet mornng spring with my whole heart I am alone, and feel the charm of existenceths spot whch was create of souls like mineing am so happy my dear frend so absori bed in the exquste sens of mere.', 'These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice hand, organizations have the need for integrating in IT departments new technologies.\n\nA wonderful serenity has taken possssion of my entire souing like these sweet mornng spring with my whole heart I am alone, and feel the charm of existenceths spot whch was create of souls like mineing am so happy my dear frend so absori bed in the exquste sens of mere.\n\nA wonderful serenity has taken posseson of my entire soung like these sweet mornngs spring enjoy with my whole heart I am alone and feel the charm of exstenceths spot whch was created ouls like mineing am so happy my dear frend so absoribed in the exquste sense of mere tranquil that neglect my talentsr I should bye ncapable of drawng and single stroke at the A wonderful se taken possesson of my entre souing like.', 'blogs/furniture-6.jpg', 'These cases are perfectly simple and easy to distinguish.', 'Theo von Gogh', 6, NULL, NULL, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(5, 'Build up their kitchen.', 'build-up-their-kitchen', 'A wonderful serenity has taken posseson of my entire soung like these sweet mornngs spring enjoy with my whole heart I am alone and feel the charm of exstenceths.', 'These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice hand, organizations have the need for integrating in IT departments new technologies.\n\nA wonderful serenity has taken possssion of my entire souing like these sweet mornng spring with my whole heart I am alone, and feel the charm of existenceths spot whch was create of souls like mineing am so happy my dear frend so absori bed in the exquste sens of mere.\n\nA wonderful serenity has taken posseson of my entire soung like these sweet mornngs spring enjoy with my whole heart I am alone and feel the charm of exstenceths spot whch was created ouls like mineing am so happy my dear frend so absoribed in the exquste sense of mere tranquil that neglect my talentsr I should bye ncapable of drawng and single stroke at the A wonderful se taken possesson of my entre souing like.', 'blogs/furniture-5.jpg', 'A wonderful serenity has taken posseson of my entire soung like these sweet mornngs spring enjoy with my whole heart I am alone and feel the charm of exstenceths spot whch was created ouls like mineing am so happy my dear frend so absoribed in the exquste sense of mere tranquil', 'Virginia Woolf', 1, NULL, NULL, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blog_category`
--

DROP TABLE IF EXISTS `blog_category`;
CREATE TABLE IF NOT EXISTS `blog_category` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `blog_id` bigint UNSIGNED NOT NULL,
  `category_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_category_blog_id_foreign` (`blog_id`),
  KEY `blog_category_category_id_foreign` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blog_category`
--

INSERT INTO `blog_category` (`id`, `blog_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 2, 2, NULL, NULL),
(3, 2, 5, NULL, NULL),
(4, 3, 3, NULL, NULL),
(5, 3, 4, NULL, NULL),
(6, 4, 2, NULL, NULL),
(7, 4, 7, NULL, NULL),
(8, 5, 6, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `brands`
--

INSERT INTO `brands` (`id`, `name`, `slug`, `image`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Designo', 'designo', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(2, 'SitWell', 'sitwell', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(3, 'NordicHome', 'nordichome', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(4, 'UrbanCraft', 'urbancraft', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(5, 'VintageVibe', 'vintagevibe', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `cache`
--

DROP TABLE IF EXISTS `cache`;
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `image`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Chairs', 'chairs', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(2, 'Sofas', 'sofas', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(3, 'Tables', 'tables', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(4, 'Coffee Tables', 'coffee-tables', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(5, 'Cabinets', 'cabinets', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(6, 'Cupboards', 'cupboards', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(7, 'Accessories', 'accessories', NULL, 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `colors`
--

DROP TABLE IF EXISTS `colors`;
CREATE TABLE IF NOT EXISTS `colors` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hex` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `colors`
--

INSERT INTO `colors` (`id`, `name`, `hex`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Black', '#000000', NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(2, 'White Broken', '#F5F5F5', NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(3, 'Turquoise', '#1DE9B6', NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(4, 'Green Lime', '#C6FF00', NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(5, 'Taupe', '#483C32', NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(6, 'Walnut', '#77604E', NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `color_product`
--

DROP TABLE IF EXISTS `color_product`;
CREATE TABLE IF NOT EXISTS `color_product` (
  `product_id` bigint UNSIGNED NOT NULL,
  `color_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`product_id`,`color_id`),
  KEY `color_product_color_id_foreign` (`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `exports`
--

DROP TABLE IF EXISTS `exports`;
CREATE TABLE IF NOT EXISTS `exports` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `completed_at` timestamp NULL DEFAULT NULL,
  `file_disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exporter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `processed_rows` int UNSIGNED NOT NULL DEFAULT '0',
  `total_rows` int UNSIGNED NOT NULL,
  `successful_rows` int UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exports_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `failed_import_rows`
--

DROP TABLE IF EXISTS `failed_import_rows`;
CREATE TABLE IF NOT EXISTS `failed_import_rows` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `data` json NOT NULL,
  `import_id` bigint UNSIGNED NOT NULL,
  `validation_error` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `failed_import_rows_import_id_foreign` (`import_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `imports`
--

DROP TABLE IF EXISTS `imports`;
CREATE TABLE IF NOT EXISTS `imports` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `completed_at` timestamp NULL DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `importer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `processed_rows` int UNSIGNED NOT NULL DEFAULT '0',
  `total_rows` int UNSIGNED NOT NULL,
  `successful_rows` int UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `imports_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_05_13_115625_create_categories_table', 1),
(5, '2025_05_13_115702_create_brands_table', 1),
(6, '2025_05_13_115711_create_products_table', 1),
(7, '2025_05_13_115719_create_addresses_table', 1),
(8, '2025_05_13_115719_create_colors_table', 1),
(9, '2025_05_13_115720_create_orders_table', 1),
(10, '2025_05_13_115724_create_order_items_table', 1),
(11, '2025_05_29_143602_create_color_product_table', 1),
(12, '2025_06_01_124925_create_settings_table', 1),
(13, '2025_06_10_140751_create_product_ratings_table', 1),
(14, '2025_06_10_192206_create_reviews_table', 1),
(15, '2025_06_11_143614_create_product_color_stock_table', 1),
(16, '2025_06_12_121833_create_blogs_table', 1),
(17, '2025_06_12_215909_create_blog_category_table', 1),
(18, '2025_06_13_100123_create_permission_tables', 1),
(19, '2025_06_14_220634_create_wishlists_table', 1),
(20, '2025_06_18_175214_create_notifications_table', 1),
(21, '2025_06_18_175218_create_imports_table', 1),
(22, '2025_06_18_175219_create_exports_table', 1),
(23, '2025_06_18_175220_create_failed_import_rows_table', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE IF NOT EXISTS `model_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE IF NOT EXISTS `model_has_roles` (
  `role_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(2, 'App\\Models\\User', 1),
(3, 'App\\Models\\User', 2),
(4, 'App\\Models\\User', 3),
(5, 'App\\Models\\User', 4),
(6, 'App\\Models\\User', 5),
(1, 'App\\Models\\User', 6),
(1, 'App\\Models\\User', 7);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `address_id` bigint UNSIGNED DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('new','processing','shipped','delivered','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_amount` decimal(10,2) DEFAULT NULL,
  `shipping_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `sub_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_user_id_foreign` (`user_id`),
  KEY `orders_address_id_foreign` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `unit_amount` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `color_id` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_product_id_foreign` (`product_id`),
  KEY `order_items_color_id_foreign` (`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'view_role', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(2, 'view_any_role', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(3, 'create_role', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(4, 'update_role', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(5, 'delete_role', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(6, 'delete_any_role', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(7, 'create_blog', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(8, 'create_brand', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(9, 'create_category', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(10, 'create_color', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(11, 'create_order', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(12, 'create_product', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(13, 'create_product::color::stock', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(14, 'create_review', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(15, 'create_setting', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(16, 'create_user', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(17, 'delete_any_blog', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(18, 'delete_any_brand', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(19, 'delete_any_category', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(20, 'delete_any_color', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(21, 'delete_any_order', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(22, 'delete_any_product', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(23, 'delete_any_product::color::stock', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(24, 'delete_any_review', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(25, 'delete_any_setting', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(26, 'delete_any_user', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(27, 'delete_blog', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(28, 'delete_brand', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(29, 'delete_category', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(30, 'delete_color', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(31, 'delete_order', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(32, 'delete_product', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(33, 'delete_product::color::stock', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(34, 'delete_review', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(35, 'delete_setting', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(36, 'delete_user', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(37, 'force_delete_any_blog', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(38, 'force_delete_any_brand', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(39, 'force_delete_any_category', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(40, 'force_delete_any_color', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(41, 'force_delete_any_order', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(42, 'force_delete_any_product', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(43, 'force_delete_any_product::color::stock', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(44, 'force_delete_any_review', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(45, 'force_delete_any_setting', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(46, 'force_delete_any_user', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(47, 'force_delete_blog', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(48, 'force_delete_brand', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(49, 'force_delete_category', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(50, 'force_delete_color', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(51, 'force_delete_order', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(52, 'force_delete_product', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(53, 'force_delete_product::color::stock', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(54, 'force_delete_review', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(55, 'force_delete_setting', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(56, 'force_delete_user', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(57, 'reorder_blog', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(58, 'reorder_brand', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(59, 'reorder_category', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(60, 'reorder_color', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(61, 'reorder_order', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(62, 'reorder_product', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(63, 'reorder_product::color::stock', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(64, 'reorder_review', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(65, 'reorder_setting', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(66, 'reorder_user', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(67, 'replicate_blog', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(68, 'replicate_brand', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(69, 'replicate_category', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(70, 'replicate_color', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(71, 'replicate_order', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(72, 'replicate_product', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(73, 'replicate_product::color::stock', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(74, 'replicate_review', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(75, 'replicate_setting', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(76, 'replicate_user', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(77, 'restore_any_blog', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(78, 'restore_any_brand', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(79, 'restore_any_category', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(80, 'restore_any_color', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(81, 'restore_any_order', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(82, 'restore_any_product', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(83, 'restore_any_product::color::stock', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(84, 'restore_any_review', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(85, 'restore_any_setting', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(86, 'restore_any_user', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(87, 'restore_blog', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(88, 'restore_brand', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(89, 'restore_category', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(90, 'restore_color', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(91, 'restore_order', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(92, 'restore_product', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(93, 'restore_product::color::stock', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(94, 'restore_review', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(95, 'restore_setting', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(96, 'restore_user', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(97, 'update_blog', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(98, 'update_brand', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(99, 'update_category', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(100, 'update_color', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(101, 'update_order', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(102, 'update_product', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(103, 'update_product::color::stock', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(104, 'update_review', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(105, 'update_setting', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(106, 'update_user', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(107, 'view_any_blog', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(108, 'view_any_brand', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(109, 'view_any_category', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(110, 'view_any_color', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(111, 'view_any_order', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(112, 'view_any_product', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(113, 'view_any_product::color::stock', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(114, 'view_any_review', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(115, 'view_any_setting', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(116, 'view_any_user', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(117, 'view_blog', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(118, 'view_brand', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(119, 'view_category', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(120, 'view_color', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(121, 'view_order', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(122, 'view_product', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(123, 'view_product::color::stock', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(124, 'view_review', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(125, 'view_setting', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(126, 'view_user', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(127, 'widget_DashboardStats', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(128, 'widget_LatestOrders', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(129, 'widget_OrderStats', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(130, 'view_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(131, 'view_any_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(132, 'create_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(133, 'update_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(134, 'delete_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(135, 'delete_any_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(136, 'restore_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(137, 'restore_any_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(138, 'force_delete_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(139, 'force_delete_any_address', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` bigint UNSIGNED NOT NULL,
  `brand_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` json DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `in_stock` tinyint(1) NOT NULL DEFAULT '1',
  `on_sale` tinyint(1) NOT NULL DEFAULT '0',
  `shipping_cost` decimal(8,2) NOT NULL DEFAULT '0.00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_brand_id_foreign` (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `products`
--

INSERT INTO `products` (`id`, `category_id`, `brand_id`, `name`, `slug`, `images`, `description`, `price`, `is_active`, `is_featured`, `in_stock`, `on_sale`, `shipping_cost`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 'Nordic Lounge Chair', 'nordic-lounge-chair', '[\"products/plantkast-1.jpg\"]', 'Comfortable lounge chair with Scandinavian design, perfect for any modern interior.', 199.99, 1, 1, 1, 0, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(2, 4, 4, 'UrbanCraft Coffee Table', 'urbancraft-coffee-table', '[\"products/salontafel.jpg\"]', 'Modern coffee table with a metal frame and oak wood top.', 349.00, 1, 0, 1, 1, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(3, 2, 1, 'Designo 3-Seat Sofa', 'designo-3-seat-sofa', '[\"products/zetel-1.jpg\"]', 'Luxurious 3-seater sofa upholstered in soft fabric. Available in several trendy colors.', 899.50, 1, 1, 1, 1, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(4, 3, 2, 'SitWell Dining Table', 'sitwell-dining-table', '[\"products/table-1.jpg\"]', 'Sturdy dining table with a minimalist design, seats up to six people.', 599.00, 1, 0, 0, 0, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(5, 5, 5, 'VintageVibe Cabinet', 'vintagevibe-cabinet', '[\"products/kast-1.jpg\"]', 'Stylish cabinet in vintage style, ideal for your hallway or living room.', 279.99, 1, 1, 1, 0, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(6, 1, 5, 'Taupe Serenity Armchair', 'taupe-serenity-armchair', '[\"products/plantkast-1.jpg\", \"products/plantkast-2.jpg\", \"products/plantkast-3.jpg\"]', 'A cozy armchair in elegant taupe with walnut wooden legs. Perfect for reading nooks or as an accent chair.', 269.00, 1, 0, 1, 1, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(7, 2, 2, 'Lime Green Modern Sofa', 'lime-green-modern-sofa', '[\"products/zetel-1.jpg\", \"products/zetel-2.jpg\"]', 'Contemporary sofa with vibrant lime green fabric. Comfortable seating for your living room.', 799.00, 1, 0, 1, 0, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(8, 3, 3, 'Turquoise Dining Table', 'turquoise-dining-table', '[\"products/table-1.jpg\"]', 'Unique dining table with a smooth turquoise finish, perfect for a stylish and lively dining area.', 689.50, 1, 0, 0, 0, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(9, 4, 4, 'Minimalist Walnut Coffee Table', 'minimalist-walnut-coffee-table', '[\"products/salontafel.jpg\"]', 'A minimalist coffee table with a rich walnut top and sturdy black legs. Ideal for modern interiors.', 325.00, 1, 0, 1, 1, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(10, 5, 1, 'Oak & Taupe Storage Cabinet', 'oak-taupe-storage-cabinet', '[\"products/kast-1.jpg\", \"products/kast-2.jpg\"]', 'Functional storage cabinet combining oak and taupe for a timeless look. Plenty of space for your essentials.', 499.99, 1, 0, 1, 0, 65.00, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `product_color_stocks`
--

DROP TABLE IF EXISTS `product_color_stocks`;
CREATE TABLE IF NOT EXISTS `product_color_stocks` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` bigint UNSIGNED NOT NULL,
  `color_id` bigint UNSIGNED NOT NULL,
  `stock` int UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_color_stocks_product_id_color_id_unique` (`product_id`,`color_id`),
  KEY `product_color_stocks_color_id_foreign` (`color_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `product_color_stocks`
--

INSERT INTO `product_color_stocks` (`id`, `product_id`, `color_id`, `stock`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 58, NULL, '2025-06-20 13:00:35'),
(2, 1, 2, 50, NULL, '2025-06-20 13:00:35'),
(3, 1, 5, 47, NULL, '2025-06-20 13:00:35'),
(4, 2, 5, 60, NULL, '2025-06-20 13:00:35'),
(5, 2, 6, 48, NULL, '2025-06-20 13:00:35'),
(6, 3, 2, 58, NULL, '2025-06-20 13:00:35'),
(7, 3, 3, 50, NULL, '2025-06-20 13:00:35'),
(8, 3, 4, 50, NULL, '2025-06-20 13:00:35'),
(9, 4, 1, 60, NULL, '2025-06-20 13:00:35'),
(10, 4, 2, 41, NULL, '2025-06-20 13:00:35'),
(11, 4, 5, 45, NULL, '2025-06-20 13:00:35'),
(12, 4, 6, 59, NULL, '2025-06-20 13:00:35'),
(13, 5, 5, 47, NULL, '2025-06-20 13:00:35'),
(14, 5, 6, 49, NULL, '2025-06-20 13:00:35'),
(15, 5, 4, 50, NULL, '2025-06-20 13:00:35'),
(16, 6, 5, 41, NULL, '2025-06-20 13:00:35'),
(17, 6, 6, 55, NULL, '2025-06-20 13:00:35'),
(18, 7, 4, 55, NULL, '2025-06-20 13:00:35'),
(19, 7, 2, 52, NULL, '2025-06-20 13:00:35'),
(20, 8, 3, 44, NULL, '2025-06-20 13:00:35'),
(21, 8, 2, 54, NULL, '2025-06-20 13:00:35'),
(22, 9, 6, 25, NULL, '2025-06-20 13:00:35'),
(23, 9, 1, 0, NULL, NULL),
(24, 10, 5, 0, NULL, NULL),
(25, 10, 2, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `product_ratings`
--

DROP TABLE IF EXISTS `product_ratings`;
CREATE TABLE IF NOT EXISTS `product_ratings` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `rating` tinyint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_ratings_user_id_product_id_unique` (`user_id`,`product_id`),
  KEY `product_ratings_product_id_foreign` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `rating` tinyint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reviews_user_id_product_id_unique` (`user_id`,`product_id`),
  KEY `reviews_product_id_foreign` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `product_id`, `rating`, `title`, `body`, `approved`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 8, 1, 5, 'Absolutely love it!', 'The chair is incredibly comfortable and the Scandinavian design looks stunning in my living room.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(2, 9, 1, 4, 'Zeer mooie stoel', 'Heel comfortabel, maar de kleur was iets lichter dan verwacht.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(3, 10, 1, 5, 'Perfect fit', 'Fits perfectly and is very sturdy. Would recommend!', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(4, 8, 2, 4, 'Good quality', 'Nice table but delivery took longer than promised.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(5, 9, 2, 5, 'Uitstekend!', 'Prachtig design en zeer stevig.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(6, 10, 2, 4, 'Solid build', 'Well built coffee table, looks sleek.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(7, 7, 2, 5, 'Love it!', 'Exactly as described, fantastic addition to my home.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(8, 8, 3, 2, 'Not great', 'I found the sofa uncomfortable and the fabric feels cheap.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(9, 9, 3, 2, 'Teleurstellend', 'Zit niet lekker en kwaliteit valt tegen.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(10, 7, 5, 3, 'Decent cabinet', 'Works well but the finish could be better.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(11, 9, 5, 3, 'Gemiddeld', 'Prima kast voor de prijs, niets bijzonders.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(12, 10, 5, 3, 'Average', 'Does the job but scratches easily.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(13, 8, 6, 5, 'Love these legs', 'The armchair is super cozy and the walnut legs look amazing.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(14, 7, 6, 5, 'Very comfortable', 'Great for reading nooks, highly recommend.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(15, 9, 6, 4, 'Erg comfortabel', 'Heerlijk om op te zitten, mooie kleur.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(16, 4, 8, 2, 'Repudiandae corporis ut quos ut sed quo unde.', 'Eaque eius in sit eos quos officia assumenda. Natus iusto dignissimos quisquam velit natus.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(17, 2, 8, 2, 'Ex commodi quia et necessitatibus voluptatem architecto ut.', 'Aut aut mollitia deserunt cum est. Eum exercitationem quibusdam sit officia. Aliquam nam a doloremque iure expedita saepe non.', 0, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(18, 1, 8, 3, 'Itaque unde corrupti qui corrupti vel sint quas vitae.', 'Architecto facilis et animi sed commodi vero deserunt. Non fuga optio natus dolor culpa quia omnis qui. Deleniti facere et sit possimus nisi maiores.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(19, 3, 8, 2, 'Et ipsum et neque earum harum sit iure.', 'Soluta quas officiis dolor qui nulla ut libero. Officia numquam est quod animi nam.', 0, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(20, 4, 10, 2, 'Consequuntur dolores minima ut et.', 'Doloribus molestias in error explicabo alias quis. Esse et sequi nisi ipsam nostrum.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(21, 2, 10, 4, 'Soluta reprehenderit vitae saepe fugiat mollitia labore.', 'Voluptatem nihil eveniet repellendus ea omnis ut. Natus aut ab voluptatem illo.', 0, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(22, 3, 10, 1, 'Recusandae rerum itaque corporis sit porro quaerat amet.', 'Et quidem sunt laudantium cupiditate. Qui labore accusamus consequuntur mollitia consequatur. Autem numquam accusantium quos eius omnis aut repudiandae.', 1, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'super_admin', 'web', '2025-06-20 13:00:30', '2025-06-20 13:00:30'),
(2, 'blog_author', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(3, 'content_editor', 'web', '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(4, 'customer_service', 'web', '2025-06-20 13:00:32', '2025-06-20 13:00:32'),
(5, 'product_manager', 'web', '2025-06-20 13:00:32', '2025-06-20 13:00:32'),
(6, 'review_moderator', 'web', '2025-06-20 13:00:33', '2025-06-20 13:00:33');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE IF NOT EXISTS `role_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(73, 1),
(74, 1),
(75, 1),
(76, 1),
(77, 1),
(78, 1),
(79, 1),
(80, 1),
(81, 1),
(82, 1),
(83, 1),
(84, 1),
(85, 1),
(86, 1),
(87, 1),
(88, 1),
(89, 1),
(90, 1),
(91, 1),
(92, 1),
(93, 1),
(94, 1),
(95, 1),
(96, 1),
(97, 1),
(98, 1),
(99, 1),
(100, 1),
(101, 1),
(102, 1),
(103, 1),
(104, 1),
(105, 1),
(106, 1),
(107, 1),
(108, 1),
(109, 1),
(110, 1),
(111, 1),
(112, 1),
(113, 1),
(114, 1),
(115, 1),
(116, 1),
(117, 1),
(118, 1),
(119, 1),
(120, 1),
(121, 1),
(122, 1),
(123, 1),
(124, 1),
(125, 1),
(126, 1),
(127, 1),
(128, 1),
(129, 1),
(130, 1),
(131, 1),
(132, 1),
(133, 1),
(134, 1),
(135, 1),
(136, 1),
(137, 1),
(138, 1),
(139, 1),
(7, 2),
(97, 2),
(107, 2),
(117, 2),
(7, 3),
(9, 3),
(17, 3),
(27, 3),
(77, 3),
(79, 3),
(87, 3),
(89, 3),
(97, 3),
(99, 3),
(107, 3),
(108, 3),
(109, 3),
(117, 3),
(118, 3),
(119, 3),
(127, 3),
(111, 4),
(116, 4),
(121, 4),
(126, 4),
(130, 4),
(131, 4),
(8, 5),
(9, 5),
(10, 5),
(11, 5),
(12, 5),
(13, 5),
(18, 5),
(19, 5),
(20, 5),
(21, 5),
(22, 5),
(23, 5),
(28, 5),
(29, 5),
(30, 5),
(31, 5),
(32, 5),
(33, 5),
(38, 5),
(39, 5),
(40, 5),
(41, 5),
(42, 5),
(43, 5),
(48, 5),
(49, 5),
(50, 5),
(51, 5),
(52, 5),
(53, 5),
(78, 5),
(79, 5),
(80, 5),
(81, 5),
(82, 5),
(83, 5),
(88, 5),
(89, 5),
(90, 5),
(91, 5),
(92, 5),
(93, 5),
(98, 5),
(99, 5),
(100, 5),
(101, 5),
(102, 5),
(103, 5),
(108, 5),
(109, 5),
(110, 5),
(111, 5),
(112, 5),
(113, 5),
(118, 5),
(119, 5),
(120, 5),
(121, 5),
(122, 5),
(123, 5),
(127, 5),
(128, 5),
(129, 5),
(14, 6),
(24, 6),
(34, 6),
(44, 6),
(54, 6),
(84, 6),
(94, 6),
(104, 6),
(114, 6),
(124, 6),
(127, 6);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `free_shipping_threshold` decimal(10,2) NOT NULL DEFAULT '1000.00' COMMENT 'Bedrag vanaf waar de klant geen verzendkosten meer betaalt',
  `free_shipping_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `settings`
--

INSERT INTO `settings` (`id`, `free_shipping_threshold`, `free_shipping_enabled`, `created_at`, `updated_at`) VALUES
(1, 1000.00, 1, '2025-06-20 13:00:26', '2025-06-20 13:00:26');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `profile_photo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `profile_photo_path`, `password`, `remember_token`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Blog Author', 'blog_author@gmail.com', '2025-06-20 13:00:31', NULL, '$2y$12$S25XjNJKlBQk6xKlU6tIxeiBkKQgQb.sZpJ5iQvroVRyFW6Fjxzqe', 'Si8Ft5j4RA', NULL, '2025-06-20 13:00:31', '2025-06-20 13:00:31'),
(2, 'Content Editor', 'content_editor@gmail.com', '2025-06-20 13:00:32', NULL, '$2y$12$745c.lNU.oyO5GCTJDCtUen/dv.Bj4712MsPnvmSm1PnYKpZ9H/Cy', 'Qj3bF2mKer', NULL, '2025-06-20 13:00:32', '2025-06-20 13:00:32'),
(3, 'Customer Service', 'customer_service@gmail.com', '2025-06-20 13:00:32', NULL, '$2y$12$mSpXn97mLko1LDFj1y3dHOWC4cGujOnh.vT5xnQgZUtyKiiLv6Wo2', 'YfdAj81xbY', NULL, '2025-06-20 13:00:32', '2025-06-20 13:00:32'),
(4, 'Product Manager', 'product_manager@gmail.com', '2025-06-20 13:00:33', NULL, '$2y$12$kJdHrEjkMDY/DUbQVnYt3OmstKijNUIe5uTbaL5nfY0kGyBmrXIYG', 'KQq4OhddRU', NULL, '2025-06-20 13:00:33', '2025-06-20 13:00:33'),
(5, 'Review Moderator', 'review_moderator@gmail.com', '2025-06-20 13:00:33', NULL, '$2y$12$gxVyekCoc6xK9mDYaokyGu9deE/noIpXqypoEnjQkMMM785H9VCx.', '3jD4ySDkj2', NULL, '2025-06-20 13:00:33', '2025-06-20 13:00:33'),
(6, 'Didier Vanassche', 'didier.v@hotmail.com', '2025-06-20 13:00:34', NULL, '$2y$12$Nxsc1Oi/sp34uGwkCMQ6Uug.knKe6Z1tA60fbkpdJ3Fa9yOpKedoa', '0AWt1cLJVt', NULL, '2025-06-20 13:00:34', '2025-06-20 13:00:34'),
(7, 'Admin', 'admin@gmail.com', '2025-06-20 13:00:34', NULL, '$2y$12$3OGl6z5ybzwOu7LfxtDyn.Ac/ox.d08xSEvoSMR.4T8lciaGPo9jm', NULL, NULL, '2025-06-20 13:00:34', '2025-06-20 13:00:34'),
(8, 'Dirk Sken', 'jan@gmail.com', '2025-06-20 13:00:34', NULL, '$2y$12$Qyn8QslAYLjKzZx7K98iTeWlWYE.Z2Lf1I7e1PwkYggrYbNFDuzmO', NULL, NULL, '2025-06-20 13:00:34', '2025-06-20 13:00:34'),
(9, 'Sophie Adams', 'sophie@gmail.com', '2025-06-20 13:00:35', NULL, '$2y$12$88jRTUpzK4.ycgJOtsLiiuNBE1.8o3TVTYAoiqDxXimFB5tIRL.Da', NULL, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35'),
(10, 'Charles Peters', 'charles@gmail.com', '2025-06-20 13:00:35', NULL, '$2y$12$4He5bMHYZ.TrEgvcKWONJuxJlM4ekI7gGxhOJuKC7JzC8i5qrhWKq', NULL, NULL, '2025-06-20 13:00:35', '2025-06-20 13:00:35');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `wishlists`
--

DROP TABLE IF EXISTS `wishlists`;
CREATE TABLE IF NOT EXISTS `wishlists` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wishlists_user_id_product_id_unique` (`user_id`,`product_id`),
  KEY `wishlists_product_id_foreign` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `blogs`
--
ALTER TABLE `blogs`
  ADD CONSTRAINT `blogs_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `blogs_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `blogs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `blog_category`
--
ALTER TABLE `blog_category`
  ADD CONSTRAINT `blog_category_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `blog_category_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `color_product`
--
ALTER TABLE `color_product`
  ADD CONSTRAINT `color_product_color_id_foreign` FOREIGN KEY (`color_id`) REFERENCES `colors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `color_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `exports`
--
ALTER TABLE `exports`
  ADD CONSTRAINT `exports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `failed_import_rows`
--
ALTER TABLE `failed_import_rows`
  ADD CONSTRAINT `failed_import_rows_import_id_foreign` FOREIGN KEY (`import_id`) REFERENCES `imports` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `imports`
--
ALTER TABLE `imports`
  ADD CONSTRAINT `imports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_color_id_foreign` FOREIGN KEY (`color_id`) REFERENCES `colors` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `product_color_stocks`
--
ALTER TABLE `product_color_stocks`
  ADD CONSTRAINT `product_color_stocks_color_id_foreign` FOREIGN KEY (`color_id`) REFERENCES `colors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_color_stocks_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `product_ratings`
--
ALTER TABLE `product_ratings`
  ADD CONSTRAINT `product_ratings_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_ratings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
